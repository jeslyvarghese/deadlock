<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Adminstrator Login</title>
</head>

<body>
<form action="wrecked_the_highs.php" method="post" enctype="application/x-www-form-urlencoded" name="form1" id="form1">
  <p>
    <label>User Name:
      <input type="text" name="username" id="username" />
    </label>
  </p>
  <p>
    <label>Password:
      <input type="password" name="password" id="password" />
    </label>
  </p>
  <p>
    <label>
      <input type="submit" name="Submit" id="Submit" value="Submit" />
    </label>
  </p>
</form>
</body>
</html>