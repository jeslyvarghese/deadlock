<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Brainbuster - Deadlock Evolution</title>
<link href="../css/index.css" rel="stylesheet" type="text/css" />
<link href="../css/reveal.css" rel="stylesheet" type="text/css" />
<script src="../scripts/jquery.js" type="text/javascript"></script>
<script src="../scripts/jquery.reveal.js" type="text/javascript"></script>
</head>
<?php include("log.php"); ?>
<body>
<div class="splashContainer">
<div data-reveal-id="logDialog" class="splash"><a href="#" data-reveal-id="logDialog"><img src="Images/spacer.png" class="splash" /></a></div>
</div>
<div class="footer">Website developed & maintained by <a href="http://www.redatom2.0fees.net" target="_blank"><b>redatom studios</b></a></div>
</body>
</html>