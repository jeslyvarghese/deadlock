<?php
session_start();
session_destroy();
echo "Thank you for palying deadlock. Do come back again! :)";
?>