<?php
$ar[] = "hello";
$ar[] = 12;
$ar[] = "hello";
$ar[] = 12;
echo count($ar);
echo 9038408;
?>