<?php #configuration
$dbname = "deadlock";
$dbuname =  "root";
$dbpwd = "walnut";
?>