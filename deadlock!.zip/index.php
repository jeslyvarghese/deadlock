<?php

   header( 'Location: code/index.php' ) ;

?>