-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 02, 2011 at 10:12 PM
-- Server version: 5.0.67
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `deadlock`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth`
--

DROP TABLE IF EXISTS `auth`;
CREATE TABLE IF NOT EXISTS `auth` (
  `ID` int(11) NOT NULL auto_increment,
  `U_ID` int(11) NOT NULL,
  `pwd` text NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `auth`
--

INSERT INTO `auth` (`ID`, `U_ID`, `pwd`) VALUES
(6, 21, '€¦‡±Å“a$˜]®Ù¾ë+m'),
(7, 22, '€¿\\sth¡ðÝÅÄ'),
(8, 23, '€sF®#_²{¶¤Çù'),
(9, 22, '€dƒS¹¾4RˆÂ¾’^ãg'),
(10, 25, '€Z\nö|õªO ÌôìÅ\Zº–3');

-- --------------------------------------------------------

--
-- Table structure for table `game_stat`
--

DROP TABLE IF EXISTS `game_stat`;
CREATE TABLE IF NOT EXISTS `game_stat` (
  `qid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `game_stat`
--


-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
  `ID` int(11) NOT NULL auto_increment,
  `Level` int(11) NOT NULL,
  `Pool` int(11) NOT NULL,
  `Question` longtext NOT NULL,
  `img` longblob,
  `Answer` text NOT NULL,
  `points` int(11) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `questions`
--


-- --------------------------------------------------------

--
-- Table structure for table `ugame_info`
--

DROP TABLE IF EXISTS `ugame_info`;
CREATE TABLE IF NOT EXISTS `ugame_info` (
  `ID` int(11) NOT NULL auto_increment,
  `q_id` int(11) NOT NULL,
  `auth_id` int(11) NOT NULL,
  `attempts` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ugame_info`
--


-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `ID` int(11) NOT NULL auto_increment,
  `email` text NOT NULL,
  `fname` tinytext NOT NULL,
  `lname` tinytext NOT NULL,
  `college` tinytext NOT NULL,
  `phn` bigint(12) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `email`, `fname`, `lname`, `college`, `phn`) VALUES
(21, 'jack@gmail.com', 'Jesly', 'Varghese', 'RSET', 919809815305),
(22, 'sims@gmail.com', 'Sims', 'John', 'MIT', 9532565),
(23, 'email', 'First', 'Last', '', 0),
(24, 'sims@gmail.com', 'First', 'Last', '', 0),
(25, 'simpson@aol.us', 'Jesly', 'Varghese', 'Rajagiri', 919809815305);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
